#include <math330.h>
#include <math.h>

double arctan(double angle)
{
    return atan(angle);
} 
