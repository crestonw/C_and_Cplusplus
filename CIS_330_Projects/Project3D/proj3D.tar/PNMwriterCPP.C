#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <PNMwriterCPP.h>

using namespace std;

PNMwriterCPP::PNMwriterCPP()
{

}

void
PNMwriterCPP::Write(char *filename)
{
	ofstream outfile;
	outfile.open(filename);

	Image *img = new Image(this->GetImg1());
		
	outfile << "P6\n" << img->GetWidth() << " " << img->GetHeight() << endl << 255;
        
	for (int i = 0; i < (img->GetWidth() * img->GetHeight()); i++)
	{
		outfile << img->GetPixels()[i].r; 
		outfile << img->GetPixels()[i].g;
	       	outfile << img->GetPixels()[i].b;
	}

	outfile.close();
}
