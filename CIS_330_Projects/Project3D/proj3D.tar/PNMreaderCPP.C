#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <PNMreaderCPP.h>

using namespace std;

PNMreaderCPP::PNMreaderCPP(char *filename)
{
	this->filename = filename;
}

void
PNMreaderCPP::Execute()
{
	// Initialize variables
	char magicNum[128];
        int width, height, maxval;
        char ch;
	//FILE *f_in = fopen(this->filename, "r");
 
	ifstream infile;
	infile.open(filename);

        // Read the header of the file into our variables 
        //fscanf(f_in, "%s\n%d %d\n%d\n", magicNum, &width, &height, &maxval);
	
	infile >> magicNum >> width >> height >> maxval;

	this->GetOutput()->SetWidth(width);
	this->GetOutput()->SetHeight(height);

	Pixel *p = (Pixel *) malloc(sizeof(Pixel) * width * height);

	int i = 0;
	while (i < (width * height)) 
	{
		infile.get(ch);
		p[i].r = ch;
		infile.get(ch);
		p[i].g = ch;
		infile.get(ch);
		p[i].b = ch;
		i++;
	}
//	fread(p, sizeof(Pixel)*width*height, 1, f_in);
/*
	for (int i = 0; i < (width * height); i++)
	{
		infile >> p[i].r >> p[i].g >> p[i].b;
	}
*/
	this->GetOutput()->SetPixels(p);

	infile.close();
//	fclose(f_in);
}
